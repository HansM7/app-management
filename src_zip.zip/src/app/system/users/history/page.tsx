export default function Page() {
  return <>History</>;
}
