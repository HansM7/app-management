import Login from ".";

function LoginPage() {
  return (
    <main className="flex flex-row justify-center">
      <Login></Login>
    </main>
  );
}

export default LoginPage;
