"use client";

function HomeUser() {
  // consumir info de base de datos sobre el usuario
  return <main></main>;
}

export default HomeUser;
