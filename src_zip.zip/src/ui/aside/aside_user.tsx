"use client";

const items = [
  {
    path: "/",
    title: "Inicio",
  },
  {
    path: "/equipments",
    title: "Equipos",
  },
  {
    path: "/users",
    title: "Usuarios",
  },
];

function AsideUser() {
  return <aside></aside>;
}

export default AsideUser;
